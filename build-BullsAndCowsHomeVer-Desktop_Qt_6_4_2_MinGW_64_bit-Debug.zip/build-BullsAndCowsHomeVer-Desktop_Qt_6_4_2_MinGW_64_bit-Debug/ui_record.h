/********************************************************************************
** Form generated from reading UI file 'record.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECORD_H
#define UI_RECORD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_Record
{
public:
    QHBoxLayout *horizontalLayout;
    QTableWidget *m_tbl_records;

    void setupUi(QDialog *Record)
    {
        if (Record->objectName().isEmpty())
            Record->setObjectName("Record");
        Record->resize(400, 300);
        horizontalLayout = new QHBoxLayout(Record);
        horizontalLayout->setObjectName("horizontalLayout");
        m_tbl_records = new QTableWidget(Record);
        if (m_tbl_records->columnCount() < 2)
            m_tbl_records->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        m_tbl_records->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        m_tbl_records->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        m_tbl_records->setObjectName("m_tbl_records");
        m_tbl_records->horizontalHeader()->setCascadingSectionResizes(false);
        m_tbl_records->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        m_tbl_records->horizontalHeader()->setStretchLastSection(true);
        m_tbl_records->verticalHeader()->setCascadingSectionResizes(false);
        m_tbl_records->verticalHeader()->setProperty("showSortIndicator", QVariant(false));
        m_tbl_records->verticalHeader()->setStretchLastSection(false);

        horizontalLayout->addWidget(m_tbl_records);


        retranslateUi(Record);

        QMetaObject::connectSlotsByName(Record);
    } // setupUi

    void retranslateUi(QDialog *Record)
    {
        Record->setWindowTitle(QCoreApplication::translate("Record", "Dialog", nullptr));
        QTableWidgetItem *___qtablewidgetitem = m_tbl_records->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("Record", "\320\237\320\276\320\277\321\213\321\202\320\276\320\272", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = m_tbl_records->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("Record", "\320\230\320\274\321\217", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Record: public Ui_Record {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECORD_H
