/********************************************************************************
** Form generated from reading UI file 'profile.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROFILE_H
#define UI_PROFILE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_Profile
{
public:
    QDialogButtonBox *buttonBox;
    QLineEdit *m_linedit_editname;
    QLabel *m_lbl_name;

    void setupUi(QDialog *Profile)
    {
        if (Profile->objectName().isEmpty())
            Profile->setObjectName("Profile");
        Profile->resize(191, 122);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Profile->sizePolicy().hasHeightForWidth());
        Profile->setSizePolicy(sizePolicy);
        buttonBox = new QDialogButtonBox(Profile);
        buttonBox->setObjectName("buttonBox");
        buttonBox->setGeometry(QRect(20, 70, 151, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        m_linedit_editname = new QLineEdit(Profile);
        m_linedit_editname->setObjectName("m_linedit_editname");
        m_linedit_editname->setGeometry(QRect(20, 40, 151, 23));
        m_lbl_name = new QLabel(Profile);
        m_lbl_name->setObjectName("m_lbl_name");
        m_lbl_name->setGeometry(QRect(20, 20, 47, 16));

        retranslateUi(Profile);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, Profile, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, Profile, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(Profile);
    } // setupUi

    void retranslateUi(QDialog *Profile)
    {
        Profile->setWindowTitle(QCoreApplication::translate("Profile", "Dialog", nullptr));
        m_lbl_name->setText(QCoreApplication::translate("Profile", "Name:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Profile: public Ui_Profile {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROFILE_H
