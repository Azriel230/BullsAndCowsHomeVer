/********************************************************************************
** Form generated from reading UI file 'mymainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYMAINWINDOW_H
#define UI_MYMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyMainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QLabel *m_lbl_chatBar;
    QPushButton *m_pb_records;
    QPushButton *m_pb_check;
    QLineEdit *m_lnedit_enterNum;
    QLabel *m_lbl_enterNum;
    QPushButton *m_pb_newGame;
    QTableWidget *m_tbl_gameRes;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MyMainWindow)
    {
        if (MyMainWindow->objectName().isEmpty())
            MyMainWindow->setObjectName("MyMainWindow");
        MyMainWindow->resize(392, 421);
        centralwidget = new QWidget(MyMainWindow);
        centralwidget->setObjectName("centralwidget");
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName("gridLayout");
        m_lbl_chatBar = new QLabel(centralwidget);
        m_lbl_chatBar->setObjectName("m_lbl_chatBar");

        gridLayout->addWidget(m_lbl_chatBar, 0, 1, 1, 1);

        m_pb_records = new QPushButton(centralwidget);
        m_pb_records->setObjectName("m_pb_records");

        gridLayout->addWidget(m_pb_records, 0, 2, 1, 1);

        m_pb_check = new QPushButton(centralwidget);
        m_pb_check->setObjectName("m_pb_check");

        gridLayout->addWidget(m_pb_check, 1, 2, 1, 1);

        m_lnedit_enterNum = new QLineEdit(centralwidget);
        m_lnedit_enterNum->setObjectName("m_lnedit_enterNum");
        m_lnedit_enterNum->setMaxLength(4);

        gridLayout->addWidget(m_lnedit_enterNum, 1, 1, 1, 1);

        m_lbl_enterNum = new QLabel(centralwidget);
        m_lbl_enterNum->setObjectName("m_lbl_enterNum");

        gridLayout->addWidget(m_lbl_enterNum, 1, 0, 1, 1);

        m_pb_newGame = new QPushButton(centralwidget);
        m_pb_newGame->setObjectName("m_pb_newGame");

        gridLayout->addWidget(m_pb_newGame, 0, 0, 1, 1);

        m_tbl_gameRes = new QTableWidget(centralwidget);
        if (m_tbl_gameRes->columnCount() < 2)
            m_tbl_gameRes->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        m_tbl_gameRes->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        m_tbl_gameRes->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        m_tbl_gameRes->setObjectName("m_tbl_gameRes");
        m_tbl_gameRes->horizontalHeader()->setStretchLastSection(true);

        gridLayout->addWidget(m_tbl_gameRes, 2, 0, 1, 3);

        MyMainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MyMainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 392, 22));
        MyMainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MyMainWindow);
        statusbar->setObjectName("statusbar");
        MyMainWindow->setStatusBar(statusbar);

        retranslateUi(MyMainWindow);

        QMetaObject::connectSlotsByName(MyMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MyMainWindow)
    {
        MyMainWindow->setWindowTitle(QCoreApplication::translate("MyMainWindow", "MyMainWindow", nullptr));
        m_lbl_chatBar->setText(QCoreApplication::translate("MyMainWindow", "\320\237\321\200\320\270\320\262\320\265\321\202! \320\224\320\260\320\262\320\260\320\271 \320\277\320\276\320\270\320\263\321\200\320\260\320\265\320\274!", nullptr));
        m_pb_records->setText(QCoreApplication::translate("MyMainWindow", "\320\240\320\265\320\272\320\276\321\200\320\264\321\213", nullptr));
        m_pb_check->setText(QCoreApplication::translate("MyMainWindow", "\320\237\321\200\320\276\320\262\320\265\321\200\320\270\321\202\321\214!", nullptr));
        m_lbl_enterNum->setText(QCoreApplication::translate("MyMainWindow", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 \321\207\320\270\321\201\320\273\320\276", nullptr));
        m_pb_newGame->setText(QCoreApplication::translate("MyMainWindow", "\320\235\320\276\320\262\320\260\321\217 \320\270\320\263\321\200\320\260", nullptr));
        QTableWidgetItem *___qtablewidgetitem = m_tbl_gameRes->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MyMainWindow", "\320\247\320\270\321\201\320\273\320\276", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = m_tbl_gameRes->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MyMainWindow", "\320\240\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MyMainWindow: public Ui_MyMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYMAINWINDOW_H
