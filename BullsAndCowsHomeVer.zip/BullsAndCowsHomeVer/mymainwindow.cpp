#include "mymainwindow.h"
#include "ui_mymainwindow.h"
#include "profile.h"
#include "record.h"

MyMainWindow::MyMainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MyMainWindow)
    , m_intValidator(1000, 9999, this)
{
    ui->setupUi(this);

    ui->m_lnedit_enterNum->setValidator(&m_intValidator);
}

MyMainWindow::~MyMainWindow()
{
    delete ui;
}

///////////

/*
 * Функция проверяет все ли цифры в 4-х значном числе разные
 * @param number_ - исходное число, записанное в виде строки
 * @return true, если все цифры разные, false иначе
 */
bool MyMainWindow::IsDiffNumbersInNumber(QString number_)
{
    if (number_[0] != number_[1] &&  number_[0] != number_[2] && number_[0] != number_[3])
        if(number_[1] != number_[2] && number_[1] != number_[3] && number_[2] != number_[3])
            return true;

    return false;
}

/*
 * Функция генерации загаданного числа: 4-х значное число с разными цифрами
 */
void MyMainWindow::GenerateHiddenNumber()
{
    do
    {
        m_random_number = rand() % 9000 + 1000;
        m_hidden_number = QString::number(m_random_number);
    }
    while(!IsDiffNumbersInNumber(m_hidden_number));
}

/*
 * Функция получает коллекцию имен пользователей из файла
 */
void MyMainWindow::GetFileRecordsData()
{
    QFile file("record_list.txt");
    if(!file.exists())
    {
        qDebug() << "Файла не существует";
        return;
    }

    QString record;
    QStringList record_split_list;

    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while(!file.atEnd())
        {
            record = file.readLine();
            record_split_list = record.split(' ');
            m_username_list.insert(record_split_list[1], record);
        }

        file.close();
    }
}

/*
 * Кнопка начала игры. Функция предлагает пользователю ввести имя игрока, после чего проверяет на уникальность введенное имя пользователя. Если оно уже есть в файле, то выдает
 * пользователю предупреждение о том, что его рекорды перезапишутся, после чего начинается игра.
 */
void MyMainWindow::on_m_pb_newGame_clicked()
{
    victory_flag = false;

    while(m_count_of_try > 0) //перед началом игры очищаем таблицу результатов
    {
        m_count_of_try--;
        ui->m_tbl_gameRes->removeRow(m_count_of_try);
    }

    Profile* profile = new Profile(this);
    profile->exec();
    m_username_main = profile->m_username;

    GetFileRecordsData();
    if(m_username_list.contains(m_username_main) || m_username_list.contains(m_username_main + "\n"))
    {
        QMessageBox* warning = new QMessageBox;
        QString message = "Внимание! Вы ввели имя пользователя, который уже есть в таблице рекордов!\nРекорд данного пользователя перезапишется!\nЧтобы этого избежать, нажмите кнопку новой игры и введите другое имя!";
        warning->setText(message);
        warning->exec();
    }

    GenerateHiddenNumber();

    ui->m_lbl_chatBar->setText("Идёт игра...");
}

/*
 * Выводит окошко с таблицей рекордов
 */
void MyMainWindow::on_m_pb_records_clicked()
{
    Record* record = new Record(this);
    record->FillRecordTable();
    record->exec();
}
\
/*
 * Проверяет введенное число на предмет быков и коров в слове по классическим правилам игры "Быки и коровы"
 */
void MyMainWindow::CheckNumber()
{
    m_bulls = 0;
    m_cows = 0;
    for(int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if(m_current_number[i] == m_hidden_number[j])
            {
                if (i == j)
                    m_bulls++;
                else
                    m_cows++;
            }
        }
    }

    m_bulls_and_cows = "Быков: " + QString::number(m_bulls) + "; Коров: " + QString::number(m_cows);
}

/*
 * После успешной проверки числа добавляет в таблицу результатов игры новую строку
 * Первый столбец новой строки - введенное число
 * Второй столбец новой строки - количество "Быков" и "Коров"
 */
void MyMainWindow::TableFill()
{
    QTableWidgetItem* item1 = new QTableWidgetItem(m_current_number);
    QTableWidgetItem* item2 = new QTableWidgetItem(m_bulls_and_cows);

    ui->m_tbl_gameRes->insertRow(m_count_of_try);
    ui->m_tbl_gameRes->setItem(m_count_of_try, 0, item1);
    ui->m_tbl_gameRes->setItem(m_count_of_try, 1, item2);

    m_count_of_try++;
}

/*
 * Функция записывает итоговый результат игры в файл рекордов
 */
void MyMainWindow::WriteIntoFileRecord()
{
    QFile file("record_list.txt");
    if(!file.exists())
    {
        qDebug() << "Файла не существует";
        return;
    }

    if (file.open(QIODevice::Append | QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream writeStream(&file);
        QString note = QString::number(m_count_of_try) + ' ' + m_username_main + "\n";
        writeStream << note;
        file.close();
    }
}

/*
 * Функция заменяет в файле рекордов старый рекорд пользователя на новый
 */
void MyMainWindow::ChangeAndWriteIntoFileRecord()
{
    m_username_list.erase(m_username_list.find(m_username_main + "\n"));
    m_username_list.insert(m_username_main, QString::number(m_count_of_try) + ' ' + m_username_main + "\n");

    QFile file("record_list.txt");
    if (!file.exists())
    {
        qDebug() << "Файла не существует";
        return;
    }

    if (file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream writeStream(&file);
        foreach (QString str, m_username_list)
        {
            writeStream << str;
        }
        file.close();
    }
}

/*
 * Кнопка проверки числа:
 * Проверяет длину числа (не меньше 4 цифр)
 * Проверяет отсутствие одинаковых цифр в числе
 * После вызывает заполнение строки в таблице результатов игры
 * Если игрок угадал слово, то выдает сообщение-поздравление и осуществляет запись в файл рекордов
 */
void MyMainWindow::on_m_pb_check_clicked()
{
    if (victory_flag)
    {
        QMessageBox* victory_warning = new QMessageBox();
        QString message;
        message = "Игра закончена. Вы - чемпион! \nДальнейшие вводы чисел не учитываются в таблице рекордов. \nЕсли хотите сыграть еще раз, нажимите на кнопку новой игры";
        victory_warning->setText(message);
        victory_warning->exec();
        return;
    }

    m_current_number = ui->m_lnedit_enterNum->text();
    if(m_current_number.size() != 4)
    {
        ui->m_lbl_chatBar->setText("Вы ввели некорректное число: длина меньше 4");
        return;
    }
    if (!IsDiffNumbersInNumber(m_current_number))
    {
        ui->m_lbl_chatBar->setText("Вы ввели некорректное число: в числе есть одинаковые цифры");
        return;
    }

    CheckNumber();
    TableFill();

    if (m_bulls != 4)
    {
        ui->m_lbl_chatBar->setText("Неправильно! Попробуй... ещё раз...");
    }
    else
    {
        victory_flag = true;
        QMessageBox* victory = new QMessageBox();
        QString message;
        message = "Правильно! Вы победили!!!\nЗагаданным числом было: " + m_hidden_number + "\n" +
                "Вы, " + m_username_main + ", угадали c " + QString::number(m_count_of_try) + " попытки!";
        victory->setText(message);
        victory->exec();

        if(m_username_list.contains(m_username_main) || m_username_list.contains(m_username_main + "\n"))
            ChangeAndWriteIntoFileRecord();
        else
            WriteIntoFileRecord();
    }
}

