#ifndef RECORD_H
#define RECORD_H

#include <QDialog>
#include <QFile>
#include <QTextStream>
#include <QString>

namespace Ui {
class Record;
}

class Record : public QDialog
{
    Q_OBJECT

public:
    explicit Record(QWidget *parent = nullptr);
    ~Record();

private:
    Ui::Record *ui;

public:
    void FillRecordTable();
    void FileSort();
};

#endif // RECORD_H
