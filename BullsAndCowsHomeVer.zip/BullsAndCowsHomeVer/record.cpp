#include "record.h"
#include "ui_record.h"
#include <QtAlgorithms>

Record::Record(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Record)
{
    ui->setupUi(this);

}

Record::~Record()
{
    delete ui;
}

/*
 * Сортирует файл рекордов по количеству попыток игрока
 */
void Record::FileSort()
{
    QFile file("record_list.txt");
    if(!file.exists())
    {
        qDebug() << "Файла не существует";
        return;
    }

    QMultiMap<int, QString> record_list;
    QString record;
    QStringList record_split_list;

    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while(!file.atEnd())
        {
            record = file.readLine();
            record_split_list = record.split(' ');
            record_list.insert(record_split_list[0].toInt(), record);
        }

        file.close();
    }

    if (file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream writeStream(&file);
        foreach (QString str, record_list)
        {
            writeStream << str;
        }
        file.close();
    }
}

/*
 * Заполняет таблицу рекордов
 */
void Record::FillRecordTable()
{
    FileSort();

    QFile file("record_list.txt");
    if(!file.exists())
    {
        qDebug() << "Файла не существует";
        return;
    }

    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {

        QString strData;
        QStringList recordList;
        int countRecords = 0;

        while(!file.atEnd())
        {
            strData = file.readLine();
            if (strData.endsWith('\n'))
                strData.chop(1);
            qDebug() << strData;
            recordList = strData.split(' ');

            QTableWidgetItem* countOfTry = new QTableWidgetItem(recordList[0]);
            QTableWidgetItem* nickname = new QTableWidgetItem(recordList[1]);

            ui->m_tbl_records->insertRow(countRecords);
            ui->m_tbl_records->setItem(countRecords, 0, countOfTry);
            ui->m_tbl_records->setItem(countRecords, 1, nickname);

            countRecords++;
        }

        file.close();
    }
}
